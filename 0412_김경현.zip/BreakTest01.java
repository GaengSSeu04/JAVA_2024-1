/*
* 작성일 : 2024년 4월 12일
* 작성자: 컴퓨터공학부 202395003 김경현
* 설명 : 1부터 입력받은 수까지 합계 출력
* 
* 문제 분석 : 초기값 :1	조건식: 입력받은수	증감식: 1씩 증가
* 			num = 1		sum = sum+num
* 
* 알고리즘:
*/
package chapter05;

import java.util.Scanner;

public class BreakTest01 {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);
		
		// 1. 합계를 원하는 정수를 입력받는다.
		System.out.print("합계를 원하는 정수를 입력하시오 : ");
		int num = stdIn.nextInt();
		// 초기값 설정
		int sum = 0, i =1;
		
		// 무한 반복문 사용
		while(true) {
			// 합계 계산
			sum = sum + i;
			// 만약 i 값이 입력받은 값과 같으면 무한반복 중지. 
			if (i== num)
				break;
			// 증감식
			i++;
		}
		// 합계 계산 출력
		System.out.println("1부터 " + num + "까지의 합계는 " + sum + "입니다.");
	}

}
