/*
* 작성일 : 2024년 4월 12일
* 작성자: 컴퓨터공학부 202395003 김경현
* 설명 : 
* 
* 문제 분석 : 
* 
* 알고리즘:
*/
package chapter05;

public class BreakTest02 {

	public static void main(String[] args) {
		int i, j;
		for (i = 1 ; i < 10 ; i++)
		{
			for(j = 1 ; j < i ; j++)
			{
				if (j > 6) {
					break;
				}
				System.out.print("0");
			}
			System.out.println();
		}

	}

}
