/*
* 작성일 : 2024년 4월 12일
* 작성자: 컴퓨터공학부 202395003 김경현
* 설명 : 점수를 입력 받아 합계와 평균을 출력하시오.
* 		음수가 입력되면 점수 입력이 종료됩니다.
* 		100점 초과의 점수는 계산에 포함되지 않습니다.
* 
* 문제 분석 : 계속해서 점수를 입력 받는다. => 무한 반복
* 
* 알고리즘:
*/
package chapter05;

import java.util.Scanner;

public class Comtinue1 {

	public static void main(String[] args) {
		
		Scanner stdIn = new Scanner(System.in);
		int sum = 0, count = 0;
		
		while (true) {
			
			
			// 1. 점수를 입력받는다.
			System.out.print("점수를 입력하시오. : ");
			int num = stdIn.nextInt();

			
			if (num < 0) {
				System.out.println("음수 입력, 종료");
				break;
			}
			
			else if (num > 100) {
				System.out.println("100점 초과, 다시 입력");
				continue;
			}
			
			else {
				sum += num;
			}
			
			count += 1;
		}
		
		System.out.println("합계 : " + sum + "\n평균 : " + (sum/count));
	}
}

